


Install packages stated below.

Copy the config folder directories to your

~.config/ 

remember to edit the sway/config for outputs including wallpaper exact location.

Also remember to edit as required the outputs to your monitors


note. No log-in manager installed. After logging in tty, just type sway and it sway should start normally

##packages installed as base:
#
networkmanager 
network-manager-applet 
dialog 
wpa_supplicant 
mtools 
dosfstools 
avahi 
xdg-user-dirs 
xdg-utils 
gvfs 
gvfs-smb 
nfs-utils 
inetutils 
dnsutils 
alsa-utils 
pipewire 
pipewire-alsa 
pipewire-pulse 
pipewire-jack 
bash-completion 
rsync 
reflector 
acpi 
acpi_call  
bridge-utils 
dnsmasq 
vde2 
openbsd-netcat 
iptables-nft 
ipset 
firewalld 
sof-firmware 
nss-mdns 
acpid 
os-prober 
ntfs-3g 
terminus-font
pipewire-x11-bell 
realtime-privileges 
bluez 
bluez-utils 
blueman
carla
pavucontrol-qt

#
##sway packages installed:
#
sway
wayland
mako
waybar
autotiling
kitty
mako
grim
grimshot
slurp
swayimg
ttf-font-awesome
otf-cascadia-code
ttf-cascadia-code 
polkit-gnome
swaybg
xdg-desktop-portal-wlr

ttf-font-awesome-5
otf-font-awesome-5
ttf-font-awesome-4
otf-font-awesome-4

##Links
#
1.https://github.com/swaywm/sway
2.https://github.com/Alexays/Waybar
3.https://github.com/swaywm/sway/wiki/Useful-add-ons-for-sway
