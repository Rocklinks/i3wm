## Current Theme

type="$HOME/.config/rofi/applets/type-2"
style='style-2.rasi'
